/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://ZsB5LhgOPcoAkyyZVDbRJ4I22l-rq4Lx_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "Communication Game"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": ""
};
